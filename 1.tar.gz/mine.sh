#!/bin/bash

./noncerpro --address='NQ62 AFCD BENG MV1S N6BM PB63 RS1X 6H4C RVSR' --threads=4 --server=nimiq.icemining.ca --port=2053 --mode=dumb
